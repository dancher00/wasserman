# SmolVLA / PushSlider (three training seeds)

Status: completed successfully. Test successes for seeds17/43/101: 5/30, 1/30, 2/30; mean8.89%, sample training SD6.94 percentage points. Validation:1/8,2/8,2/8. All114 evaluation episodes physically rescored, no terminal exceptions. Total pipeline time80.69minutes. Original paper/site are unchanged.

Protocol: [PROTOCOL.md](PROTOCOL.md). Branch: study/pushslider-smolvla-5090.
The existing frozen environment is inherited from wm-open-v2-20260929.

## Execution
From the repository root with its existing verified simulator environment:

```sh
uv pip install --python .venv/bin/python --target .deps/smolvla-extras num2words==0.5.14
.venv/bin/python scripts/prepare_pushslider_smolvla.py
.venv/bin/python scripts/run_pushslider_smolvla_study.py
```

Preparation downloads only the pinned public model weights/config/tokenizer;
private demonstrations are decoded locally from existing verified archives into
`/dev/shm/wasman-smolvla-PushSlider` (about29GiB). Nothing uploads to Hugging Face.
Three trainings run concurrently. The pipeline then runs eight validation and30
test resets per checkpoint, sequentially, and performs independent physical
rescoring and generates compact result tables, a figure and manuscript text.
Fresh output paths are required. No automatic retry or checkpoint selection.

Current detached service: `wasman-smolvla-pushslider.service` (user systemd).
Its log is `artifacts/pushslider-smolvla-5090/pipeline.log`.
Each job has a JSON command/source receipt, a log and GPU telemetry. A job failure
leaves a visible `pipeline-status.json`; no later analysis is labeled complete.
The service survives this chat turn; machine reboot does not resume a training.
Periodic `latest.pt` files contain learned weights, not optimizer-resume state.

## Outputs
- `train-{17,43,101}`: config, unsmoothed training loss, final delta checkpoint.
- `validation-SEED` and `test-SEED`: physical trace, initial image, predictions,
  success contract and independently rescored report.
- `summary.json`, `episodes.csv`, `comparison.json`, `paper-text.md` and
  `pushslider-comparison.{pdf,svg,png}` are generated only after all evaluations.
- `delta-check.json` checks exact reconstruction from the pinned frozen base and
  saved trainable deltas; all model parameters are explicitly FP32.

Pretrained dependencies and experiment code hashes: `environment.json`.
Capacity measurements are engineering checks, not evidence of task success.
The new model uses a constant language instruction; this experiment does not
measure language generalization. Pretraining and compute differ from ACT/DP/BC.
