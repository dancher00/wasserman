# PushSlider SmolVLA study — 2026-10-01

## Material Passport
Author-side implementation and execution record. Local raw simulation data only;
no external data upload. Results pending. Scope: three training seeds explicitly requested by the user on 2026-10-01.
Additional algorithm study; original ACT/DP/BC results are not rewritten.

## Fixed design before learned-policy rollout
- Task: PushSlider, open-procedural-v1; original frozen wm-open-v2-20260929
  physics, reset logic, success contract, wrist renderer and native actuator decoder.
- Existing 80 successful audited expert demonstrations, split exactly 76/4 with
  split seed 20260929. Lossless RGB decoded into /dev/shm and SHA-256 verified;
  no lossy conversion, no duplicated SSD dataset.
- Initialization: lerobot/smolvla_base, revision
  d9f33c94a60fb382c90dea2164c96845bd955e28; tokenizer/config
  HuggingFaceTB/SmolVLM2-500M-Video-Instruct revision
  7b375e1b73b11138ff12fe22c8f2822d8fe03467. Local LeRobot commit
  a16f34c085c9597fcbdb9fde395a3334d78df716. Strict pretrained load.
- Single wrist RGB 384x384; model's own 512x512 padded image preprocessing.
  Eight measured actuator-state dimensions and eight absolute action targets.
  Training-only mean/SD normalization as existing ACT dataset. No object states.
- Prompt: `Push the slider along its rail to the target position.` plus newline.
- Seeds 17, 43, 101; chunk 16, execute first 8 at native 30 Hz; synchronous simulation.
  Flow matching, 10 inference steps; FP32 inference. No real-time deployment claim.
- Freeze VLM/vision backbone, train action expert and state projection using the
  upstream pretrained configuration. No new base-model training.
- Training: 320000 sampled windows, batch 32, 10000 updates, microbatch 32 (capacity checked before scored training);
  no padded windows, same train partition as ACT/DP. AdamW lr 1e-4,
  betas .9/.95, eps 1e-8, weight decay 1e-10, clip 10. Linear warmup 1000 updates,
  cosine decay to 2.5e-6 by update 10000. BF16 autocast, FP32 parameters.
- Separate 25-update engineering capacity run discarded; restart initialization
  and random seeds for actual trainings. No policy outcomes used to choose budget.
- Fixed-final-budget checkpoint; no best-test selection. Save trainable parameter
  delta and buffers against pinned frozen base, not multiple full backbone copies.
- Full-horizon closed-loop validation: reset IDs 54000–54007, rollout noise seed42,
  1790 control steps at30Hz, first-episode success independently rescored from
  physical trajectory. No overlap with demonstration IDs44000–44079 or reserved
  primary IDs64000–64029. After validation, run the full fixed primary reset cohort64000–64029 for each seed.
  These are the existing benchmark test states, not claimed to be newly untouched.
- Validation success, per-reset time to success/progress and loss curve reported,
  including failures. Report each seed and mean/SD across three trainings; conditional binomial
  intervals per seed. Paired reset comparisons to existing DP are descriptive,
  with training seed as the unit of training variability. No compute/pretraining
  matching claim. Do not pool 90 episodes as 90 independent training runs.
- Additional development rollout may check adapter execution before full validation;
  no hyperparameter selection from its task outcome.

## Implementation and constraints
Separate branch study/pushslider-smolvla-5090. Frozen rollout source copied into
an explicitly separate SmolVLA script; physics source and original baselines stay
unchanged. No shared article/site edits. Checkpoints and data remain local/private.
Initial package smoke failed for missing num2words; isolated extras install fixes
that dependency. Transformers warns about a text config padding ID while building
the action expert; no text tokens are embedded by that expert. End-to-end forward,
backward and action prediction are checked explicitly before training.

## Sources
https://huggingface.co/docs/lerobot/v0.5.0/smolvla
https://huggingface.co/lerobot/smolvla_base

## Capacity and execution freeze
FP32 parameters/BF16 autocast: 25 updates in2.961s, peak5,414,219,776bytes.
Three concurrent training processes; subsequent rollout jobs sequential.
Dedicated launcher reserves36GiB SSD; generated training deltas ~400MB each.
RGB remains in RAM. Engineering runs are not scored study results.
A mistaken unsupported --headless flag was rejected before the initial rollout;
launcher default visualizer=none is the supported headless configuration.
Model initialization was changed to explicit FP32 before study training after
engineering tests revealed mixed parameter dtypes from upstream model config.
Comparison graph uses mean ± sample training SD and shows each training seed;
its layout is provisional, not a claim of venue formatting compliance.
