# Current and underwater contact: registered design

## Material Passport

Study: `wm-current-contact-5090-v1`. Owner: requesting human author. Executor:
Codex on RTX 5090. Type: controlled simulation sensitivity study using existing
policies. Parent: `wm-open-v2-20260929`, assets `open-procedural-v1`.
Status: frozen after the expert pilot and short performance checks, before
the 540-episode evaluation. Exact commitment: `freeze.json`. No new training. No edits to
the shared manuscript or website. Outputs stay in the existing private GitHub.

## Question and intervention

How does a constant transverse water velocity change completion and early
contact/vehicle response of fixed visual DP policies on OpenHatch and RotateValve?
Two tasks × three existing training seeds (17, 43, 101) × three conditions ×
30 ordered resets = 540 scored episodes in 18 separate 30-environment rollouts.

Conditions are world water velocities `(0,0,0)`, `(0,0.10,0)` and `(0,0.20,0)`
m/s, with no turbulent component. Positive Y is lateral to the nominal +X
approach: parallel to the Valve panel (wheel axis X) and the initial horizontal
Hatch plane, transverse to approach. These values already appear in
`scripts/evaluate_water_motor_study.py`; the inherited scene current-speed
range extends to 0.22 m/s. Moderate/strong mean relative to these selected
conditions, not calibrated ocean severity. Values are selected before observing
any DP response. A short expert pilot checks implementation, finite physical
response and direction; it does not optimize currents to induce policy failure
or demonstrate full-horizon expert feasibility.

Existing evaluator settings already set random current and turbulence to zero.
All scene, contact, hydrodynamic-coefficient distributions, thruster limits,
controller gains, lights, cameras, policy weights, precision, action decoding
and success code remain unchanged. Only `_mean_current_w` is assigned the
registered vector; `_turbulent_current_w` remains zero. No thruster-allocation
patch is used. The wrapper retains existing random-number draws even when
multiplied by zero, and adds no random draws. It uses frozen evaluators through
`runpy`, replacing only the old controller-study cohort validator with the new
study's strict cohort/checkpoint gate. The original general evaluation guard and
all 150 frozen runtime files remain intact.

Water velocity starts immediately before the single 30-Hz camera-warmup step,
after the zero-current reset snapshot. It is held constant during that step and
all scored steps. Record pre-current physical state and parameter scales,
post-warmup state, and state before the first applied policy action; the latter
follows the camera-only updates and first inference, with no intervening physics.
First inference inputs remain in the original prediction trace. Post-warmup
states may differ across conditions; pre-current states must match. The fixed
policy remains in feedback, so actions can differ when observations differ.

## Model and reset binding

`protocol.json` gives full model/config SHA-256 identities, ordered IDs and
rollout noise seed 42. No checkpoint selection. The same ordered 30-slot batch
is used for every condition/checkpoint within a task. All three training seeds
share task reset IDs. New IDs:

| Task | Expert pilot (2) | Speed/memory benchmark (30) | Evaluation (30) |
| --- | --- | --- | --- |
| RotateValve | 9100100–9100101 | 9110100–9110129 | 9120100–9120129 |
| OpenHatch | 9100200–9100201 | 9110200–9110229 | 9120200–9120229 |

`seed-audit.json` scans recorded seed fields and excludes the full reserved
30000–99999 interval. Pilot, speed-benchmark and evaluation IDs are mutually
disjoint. Never substitute an older still-water cohort for the baseline.
Expert pilots use unchanged task experts, including the already established
Valve approach offset −0.020 m and target 172.5 degrees, for 150 control steps
on two development states per condition. These are not counted in the 540.

## Outcomes and exposure

Full success is the unchanged physical predicate, rescored from the original
saved tensors: HatchContract for OpenHatch, signed angle ≥170 degrees for
RotateValve. Full horizons are 1790 and 2240 control steps respectively at
30 Hz, excluding warmup. First success time is `first_success_step / 30`;
failure/termination has no success time. Report success-conditional times with
their denominator, and capped completion time (success time if observed,
otherwise the declared full horizon), explicitly as a composite metric rather
than an observed success time for failures.

All early metrics use the first 600 post-warmup control samples (20 seconds),
excluding reset samples and everything after first success/termination. Report
actual individual exposure. For a paired current contrast, restrict both traces
to their common valid prefix so exposure is identical within that pair; report
that duration per reset. Short or zero exposure is explicit; no extrapolation,
zero padding or continued-episode fabrication. Independently observed summaries
and paired common-window summaries are separate. Conditional censoring can
change the population represented by early metrics.

Record and recompute:

- Mechanism signed net progress and maximum progress in degrees, final valid
  full-horizon angle, and signed progress while opposing contact is present.
- Common opposing-contact indicator: both mechanism-filtered finger-force norms
  strictly greater than 0.1 N and the dot product of their unit vectors below
  −0.25. Report task-native grasp flags separately; they have task-specific
  semantics and are not silently pooled into the common indicator.
- Established contact: three consecutive valid opposing-contact samples (0.1 s).
  Loss: after establishment, three consecutive valid samples without opposing
  contact. Timestamp is the confirming third sample. Count one loss per contact
  spell; reacquisition requires three consecutive positive samples. Absence of
  any initial establishment is never a loss. Report acquired count, lost count
  over all episodes and loss conditional on acquisition, with denominators;
  latter is descriptive because acquisition can be affected by current.
  Loss is a kinematic contact event, not necessarily an unintended failure;
  planned release is not excluded using expert labels or future outcomes.
- Base displacement RMS from its pre-current position; station-position-error
  RMS relative to the controller's possibly moving commanded position; world-
  identity attitude RMS (not generic orientation tracking); base linear/angular
  velocity; recorded quaternion and rotation-error components.
- Motor-force RMS (across motors and samples), peak realized force magnitude,
  peak normalized utilization using asymmetric force limits, and fraction of
  samples where allocation scale < 1−1e−6. These are 30-Hz control samples,
  not physics-substep force peaks.

Save the complete original physical scoring trace and additional robot/base,
mechanism, motor, water-current and contact trajectories. Inactive batch slots
may continue to be simulated by the frozen evaluator, but never enter a metric
or video after their first success/reset. All nonfinite values, unexpected
resets, incomplete horizons or pairing/config mismatches are explicit errors
or retained exclusions, never silent removal of unsuccessful episodes.

## Analysis fixed before evaluation

Give all episode rows and each training seed's success count/30, then equal-
training means and sample SD over three trainings. Do not treat 90 episodes as
90 independent trainings. Moderate-minus-zero and stronger-minus-zero are the
four primary task/condition contrasts. Stronger-minus-moderate is descriptive.
No pooled cross-task ranking is planned.

For success and common-prefix continuous contrasts, use a paired crossed
percentile bootstrap: 20,000 draws, RNG seed 20261001; sample three training
indices with replacement and 30 reset indices with replacement, sharing both
index draws between conditions and reset draws across training indices. Report
2.5/97.5 percentiles and paired point differences. Intervals are descriptive,
marginal and not adjusted for multiplicity; three trainings give limited
coverage of training variability, and all-success/failure boundaries can give
degenerate intervals. Missing continuous values remain missing with explicit
sample counts; if no finite contrast exists, report null and no interval.
Keep negative, zero and unresolved effects. No tuning after DP outcomes.

## Execution and storage

First run short sequential performance checks, 30 environments per rollout,
then a maximum of two independent processes only if VRAM leaves at least 4 GiB
headroom. Never change within-rollout batch size, renderer, precision or noise
assignment. If concurrent throughput is not beneficial, use sequential runs.
Jobs record wall time and GPU telemetry, have explicit timeouts, and stop before
the inherited 40-GiB SSD reserve. Failures get new labeled attempts after a
recorded diagnosis; no overwriting failed outputs or automatic outcome retries.
Exact commands are retained in job receipts. Only redundant generated material
with retained verification evidence may be removed.

## Demonstration selection and handoff

After analysis, for each task use training seed 17 and select the smallest reset
ID with success at zero current and failure at 0.20 m/s; if none exists, select
the smallest ID where the outcomes differ; otherwise select the smallest ID.
Record zero/0.20 paired clips, at most four. Re-run the same full ordered batch
and record only the selected slot, without audio/text overlay. End the clip at
its own first success/reset or horizon. Record video-run outcome and agreement
with the scored run; reruns never replace statistical evidence. Video recreation
can differ because exact rollout determinism is not established.

Handoff: protocol, commands/environment, identities, episode/seed tables,
rescoring/pairing audit, executable analysis, blue PDF/SVG/PNG figures, video
manifest, and a short manuscript-ready text with results and limits. The study
is simulation current sensitivity; no calibration, CFD validation, hardware
transfer or universal current robustness claim. Human author verification of
the final interpretation remains pending.
