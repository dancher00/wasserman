# WasserMan-Bench: current/contact study on RTX 5090

This directory is the handoff for `wm-current-contact-5090-v1`, separately from
the manuscript/site and the other workstation's nondeterminism investigation.
Read `PROTOCOL.md` and `protocol.json` first. Preparation failures are retained
in `preparation-notes.md`; only complete, physically audited cohorts enter the
results. The study uses six fixed open-profile DP checkpoints and no training.

All 540 planned episodes and four selected video reruns are complete. Physical
rescoring retains every episode, with no reset exceptions; all early metric
windows are the full 20 seconds. A second analysis execution reproduces all six
result files byte-for-byte. See [the integration text](paper-text.md) for the
numerical results and bounded interpretation, and [the internal critical
assessment](review/assessment.md) for claim limits. The assessment is by the same
executor, not independent peer review.

## Reproduce

Use the parent project's verified dependency environment and restore the six
model folders identified in `protocol.json` from the existing private core
release. Preserve the exact checkpoint/config bytes. The scripts are executed
from the repository root with `.venv/bin/python`; each job sets
`WASMAN_ASSET_PROFILE=open-procedural-v1` and the pinned policy overlay through
`scripts/run_revision_job.py`.

The parent [package restoration instructions](../../docs/revision-v2-packages.md)
and [private release catalog](../revision-v2-release-catalog.json) identify the
existing task/model packages. This study archive adds new evidence; it does not
duplicate those model weights or claim unauthenticated availability.

The finite driver retains exact backend commands and environment/source hashes
in `artifacts/current-contact-5090/jobs/*.json`, with matching `.log` and GPU
telemetry `.gpu.jsonl` files. Do not overwrite a completed or failed output.

```bash
.venv/bin/python -m unittest discover -s tests -p test_current_contact_metrics.py
.venv/bin/python scripts/run_current_contact.py --stage evaluation
.venv/bin/python scripts/analyze_current_contact.py
.venv/bin/python scripts/plot_current_contact.py
.venv/bin/python scripts/run_current_contact.py --stage video
.venv/bin/python scripts/finalize_current_contact.py
.venv/bin/python scripts/audit_current_contact_handoff.py
```

Once the study archive is restored, analysis and plotting can be repeated from
the saved tensors without running the simulator. Use `--output` on the analysis
script to write comparison tables to a separate directory. Evaluation and video
recreation require the original simulator environment and complete ordered
30-environment batches. A new recreation is never substituted for a scored run.

The evaluation driver requires the frozen protocol and matching study sources.
Existing complete jobs are retained; an incomplete attempt stops the driver for
inspection. A process exit code alone is insufficient because simulator shutdown
can mask Python exceptions. Analysis additionally checks complete horizons,
physical success, current vectors, model identities, matching configurations and
pre-intervention states.

## Deliverables

- `environment.json`, `seed-audit.json`, `pilot-audit.json`, `performance.json`:
  preparation and runtime evidence.
- `freeze.json`: pre-evaluation protocol/source commitment.
- `commands.json`: all 35 exact job commands/receipts, including retained
  preparation attempts; failed attempts are not scored cohorts.
- `results/episodes.csv` and `.json`: all 540 outcomes and exposure-aware metrics.
- `results/training-seeds.csv`: each of the three trainings separately.
- `results/summary.json`: means, between-training SD and paired bootstrap effects.
- `results/paired-episodes.json`: per-reset matched-prefix comparisons.
- `results/audit.json`: physical rescoring, pairing, exceptions and hashes.
- `figures/`: blue PDF/SVG/PNG figures, captions and source manifest.
- `video-selection.json` and `video-manifest.json`: fixed selection rule and
  recorded-rerun outcomes, not replacement evaluation evidence.
- `analysis-repeat.json`, `figure-check.json`, `video-check.json`: repeated
  analysis and local visual inspection records.
- `paper-text.md`: concise methods/results/limits for the other workstation.
- `handoff-audit.json`: artifact hashes, independently recomputed count/SD checks,
  paired exposure checks and the scope of the final consistency audit.
- `release.json`: new private release and archive checksums after upload.

The release receipt is added after authenticated upload/download verification;
it is not embedded in the archive whose identity it verifies. No public or
anonymous access is asserted. No physical tank,
CFD, hardware transfer or broad current-robustness claim is supported by this
simulation sensitivity experiment.
