# SmolVLA on PressButton and PullLever — 2026-10-01

## Material Passport
Author-side experiment execution. Status at preregistration: results pending.
Extension explicitly requested by the user after the PushSlider SmolVLA study.
No manuscript/site changes; no external upload of training data.

## Fixed before scored training/evaluation
Each task: three independent training seeds17/43/101, fixed-final checkpoints,
320,000 sampled windows per training, 10,000 updates with batch/microbatch32.
Same pretrained model revision, frozen backbone, optimizer, scheduler, BF16
training autocast and explicitly FP32 parameters/inference as the completed
PushSlider study. Chunk16, execute8 at30Hz, flow10 steps, no asynchronous inference.
One wrist image384x384, upstream padded resize512x512, training-only state/action
mean/SD. Same original 76/4 episode split (split seed20260929); no padded windows.

Pretrained model: lerobot/smolvla_base revision
`d9f33c94a60fb382c90dea2164c96845bd955e28`. VLM config/tokenizer:
HuggingFaceTB/SmolVLM2-500M-Video-Instruct revision
`7b375e1b73b11138ff12fe22c8f2822d8fe03467`. Pinned LeRobot
`a16f34c085c9597fcbdb9fde395a3334d78df716`; strict full pretrained initialization,
trainable delta checkpoints. Training freezes vision/language and tunes the action
expert and state projection. AdamW1e-4, betas(.9,.95), eps1e-8, decay1e-10, clip10;
1000-step linear warmup then cosine to2.5e-6 at10000. No budget or checkpoint
selection from new evaluation outcomes.

| Task | State/actions | Constant instruction | Validation resets | Test resets | Horizon |
|---|---|---|---|---|---|
| PressButton |21/10|Press the button.|50000–50007|60000–60029|470 steps|
| PullLever |8/8|Pull the lever to the target position.|55000–55007|65000–65029|1790 steps|

Instructions end with newline. Native actuator interface, existing physical success
criteria, cameras and open-procedural-v1 scenes are unchanged. Source protocol:
wm-open-v2-20260929. No expert inputs to learned-policy inference. Rollout seed42.
Validation/test reset cohorts are existing benchmark cohorts, not newly untouched
states; they do not overlap the task's selected demonstrations. Check this explicitly
from actual dataset and checkpoint metadata. Run 8+30 resets per training =114/task,
228 total. PressButton uses its own physical scorer, including travel upper bound,
tool speed and mechanism speed; do not apply the weaker marine scorer to it.

## Execution gates and storage
Three trainings per task run concurrently; tasks run sequentially. Gate each task
with25 engineering training steps plus12 control steps on30 development resets:
PressButton9945000–9945029, PullLever9946000–9946029. These are capacity/interface
checks, not task-success evaluations; do not tune hyperparameters from outcomes.
Failures stop the pipeline visibly, without automatic retries. Record commands,
source/checkpoint hashes, finite losses and GPU utilization/memory. No new expert
collection. Existing lossless archives are decoded with byte verification into RAM:
selected80 PressButton episodes ~5.26GiB; PullLever ~36.41GiB. Remove only generated
RAM copies after validating persistent archive hashes. Keep36GiB SSD reserve.

## Reporting
Report each seed separately, mean and sample SD across three trainings. Conditional
exact95% binomial intervals per checkpoint describe reset uncertainty, not training
uncertainty. All physical traces retained; rescore all successes from the original
per-task physical criteria. Record terminal exceptions separately, never silently
exclude failed episodes. Save negative/mixed outcomes. Figures display each seed
plus mean±training SD. Compare descriptively with original ACT/DP/BC results;
compute, architecture and pretraining are not matched. Constant prompts do not
establish language generalization, and simulation results do not establish transfer.

## Relationship to prior study
No retuning based on PushSlider results. Only task identity, required state/action
dimensions, instruction, training episodes, horizon and prescribed reset IDs change.
See research/pushslider-smolvla-5090/PROTOCOL.md for the earlier study and checks.
