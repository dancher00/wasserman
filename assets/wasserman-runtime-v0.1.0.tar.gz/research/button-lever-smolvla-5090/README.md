# SmolVLA extension: PressButton and PullLever

Status: complete. PressButton test:15/30,18/30,16/30 (54.44% mean,5.09pp training SD). PullLever test:4/30,1/30,2/30 (7.78% mean,5.09pp training SD). All228 evaluation episodes physically rescored; no terminal exceptions. Six trainings complete. An initial pre-episode RTX startup crash was preserved; unchanged lever evaluations completed after explicit continuation.
Protocol: [PROTOCOL.md](PROTOCOL.md).

Existing simulator and dependency setup, pinned pretrained cache and isolated
num2words dependency are inherited from the completed PushSlider SmolVLA study.
Run from repository root:

```sh
.venv/bin/python scripts/prepare_button_lever_smolvla.py --task PressButton --cleanup PushSlider
.venv/bin/python scripts/run_button_lever_smolvla_study.py
```

The driver prepares PullLever after completing PressButton, checks training and
30-environment rollout capacity, trains seeds17/43/101 in parallel per task, then
runs validation/test and analysis. Each task produces summary.json, episodes.csv,
comparison.json, PDF/SVG/PNG comparison figures and paper-text.md in its research
subdirectory. Physical evidence, weights, job receipts and telemetry remain under
artifacts/button-lever-smolvla-5090/TASK.

User-systemd service: wasman-smolvla-button-lever.service. Pipeline log and explicit
completion/failure status are in artifacts/button-lever-smolvla-5090. The detached
service runs without this chat turn; machine reboot does not resume training.
Periodic learned-weight checkpoints do not contain optimizer-resume state.
No automatic retries or use of incomplete results as completed experiments.

Config bookkeeping inherited from the ACT template is explicitly qualified in
metadata-clarification.json; use job receipts for executed source and environment.json
for the study code, rather than inherited ACT parameter/worker/source fields.
