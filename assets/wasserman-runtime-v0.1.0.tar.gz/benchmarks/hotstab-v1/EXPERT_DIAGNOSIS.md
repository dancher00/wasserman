# Development diagnosis (not final benchmark results)

Initial expert from ea19943 was successful on its single demonstration state,
but only 2/8 on the independently generated development poses (1000–1007).
No learned model had been trained at this point.

In five trials the plug rotated to about 80 degrees pitch during lift while the
controller held a fixed **tool** orientation. Opposed finger contacts disappeared
and the plug fell. The insertion feedback then continued chasing an unheld object.
A sixth failure (1005) lost contact during insertion. The complete initial trace,
data timing/contact audit and first event times are in expert_initial_diagnosis.json
and the local archived trial `artifacts/hotstab_v1/benchmark_dev00`.

Trial01 added plug-orientation feedback during lift. It completed 3/8, but did not
fix the five early losses. Therefore this was not accepted as a general expert.
Trial02 tried horizontal side grasping of the flat handle: four environments
crossed the base-height limit, others later lost contact. It was stopped early
once this failure was established; it is not a completed benchmark evaluation.
Its source archive and log remain in `benchmark_dev02`.

Trial03 tests an oblique approach and URDF-derived posture targets: jaws close
across the broad surfaces of the paddle, with orientation established at clearance
height before descent. Grasp shape, object mass, friction, actuator force limits,
scene geometry, cameras and success criteria are unchanged in these trials.

## Physical audit scope

Initial plug/socket peak overlaps were 0.110–0.117 mm for insertion trials;
plug/sand overlap was approximately 0.594 mm across all eight states.
The existing 0.5 mm diagnostic tolerance remains unchanged and fails on sand.
No claim of zero penetration is made. The precise backend cause remains unresolved.
The default rest offset is documented as zero by the
[NVIDIA ovphysx schema contract](https://nvidia-omniverse.github.io/PhysX/ovphysx/latest/population/PhysxCollisionAPI.html);
we have not attributed this overlap to an explicitly authored negative rest offset.

A separate new URDF FK audit checks the recorded arm/wrist cylindrical collision
proxies against all authored station mesh colliders and the ground. Trial01 state1004
passed with zero detected proxy overlap and TCP reconstruction error 0.000000593 m.
This excludes finger contacts, robot self-collision and intermediate physics substeps.

## Accepted direction and collar contact correction

Trial04 returned to the original top approach and moved the grip centre from
x=-92 mm to x=-78 mm, near the widened handle root. It completed 5/8 development
states. The other three lost the object while orienting it. This changes the
controller target, not the handle, contact coefficients or actuator limits.

An explicit 64-vertex cooking budget did not resolve the original resting overlap.
Partitioning the collar into 32 triangular prisms did: across the same eight reset
states over 150 steps, peak authored-geometry penetration into sand was 0.122 mm,
with seven states below 0.0003 mm. `collar_partition_review.json` verifies the
cross-section union and original extrusion bounds, with zero overlap between the
prisms, unchanged mass/inertia and material bindings. Thus the collision volume
has not been inflated. The precise internal hull simplification path is not claimed
to have been inspected; the contact difference is measured directly.

Trial05 tested the complete root-grasp expert on the corrected collar contacts.
Seven states lost the object; the trial was stopped before completion. Trial06
tried the root/collar boundary (x=-70 mm, z=0); all eight lost contact on lift.
Both interrupted trials retain source snapshots and logs, and are not final results.

A 32-environment collar sweep compared four target offsets on copies of the same
eight development poses. None completed: x=-60 mm, z=-6 mm slipped during lift,
while the three deeper variants remained blocked during approach. A nominal
68 mm jaw aperture at one CAD section does not establish clearance through the
whole curved finger geometry around the 62 mm collar.

The next targeted sweep tests deeper engagement of the existing narrow handle:
(-92, 0, -14), (-100, 0, -14), (-105, 0, -10), (-83, 0, -14) mm.
The handle geometry and physical parameters remain unchanged.
No learned-policy training or final-test rollout has been used for these corrections.

## Frozen grasp target

The depth sweep completed with 6/8, 7/8, 8/8 and 6/8 successes, respectively.
The selected existing-handle target is (-105, 0, -10) mm in plug coordinates,
near the rear flare. It produced actual lift, insertion, release and the unchanged
2-second hold criterion in all eight development poses. The full source snapshots
and per-state trajectories are in `benchmark_grasp_depth`; pilot IDs 1220–1227
map directly to development IDs 1000–1007. No handle reshaping was needed.

This isolates the actionable expert defect to shallow/inappropriate engagement
of the curved CAD fingers. A single fully-open cross-section clearance check had
not certified holding engagement. The selected controller is being repeated with
fixed cameras and audited before any imitation training.

## Fixed-camera collection and exact command replay

The selected expert repeated 8/8 successes with both fixed cameras. All eight
episodes passed plug/environment, arm/wrist and conservative finger-envelope
audits at 30 Hz. The recorded actuator commands replayed with identical robot
state and plug poses at every sample, identical episode durations and 8/8 success.
The maximum recorded contact-vector difference was below 1e-6 N.

Camera timestamps exactly match the float32 sum of eight 1/240 s physics steps per
image. An earlier float64 ideal-clock comparison caused a false rejection and was
replaced with the actual simulator clock recurrence; no recording rate changed.
Initial replay RGB is not bit-identical: mean absolute differences were 0.318–0.390
levels out of 255 for the base camera and 0.061–0.080 for the wrist, with p99 <=2.
The audit preserves these differences and uses explicit <=1 mean / <=4 p99
8-bit-level rendering tolerances; physical replay tolerances remain unchanged.

Two-update smoke checks of ACT and DP passed finite training and checkpoint
loading. On 24 recorded observations, deployed preprocessing, observation history,
denormalization and action-queue execution matched direct model calls exactly.
These development-only smoke weights are excluded from final evaluation.
