# Restoring the benchmark

Use the repository revision attached to the `hotstab-act-dp-v1` release and the
runtime/dependency versions in `environment.json` and `python_environment.txt`.
Install the licensed robot CAD through the root README; original CAD is not
redistributed in dataset or source archives. Source manifests include its hashes.

## Data

Download all `hotstab-dataset-*.tar` parts and the corresponding `.sha256` files
from the release. Verify each checksum file with `sha256sum -c FILE` in the
download directory. Extract all tar parts into one directory. They produce
`encoded/development00`, `encoded/train00`, and `encoded/train01`.

For each batch, restore the lossless RGB transport:

```bash
OPENBLAS_NUM_THREADS=1 .venv/bin/python scripts/transport_hotstab_dataset.py \
  --mode restore --source DOWNLOAD/encoded/development00 \
  --output artifacts/hotstab_v1/benchmark_final/data/development00 --workers 4
```

Repeat for `train00` and `train01`. The restore command verifies compressed and
raw camera SHA256 values. Copy the checked-in `dataset_manifest.json` into the
data root. Retain failed episodes and their metadata; the learner uses only the
59 successful audited training demonstrations. The eight development episodes
are for validation and checkpoint selection. Test demonstrations are excluded.
The data occupies much more space after lossless video is decoded to raw RGB.

## Weights and evaluation

Verify `hotstab-results.sha256` and extract `hotstab-evaluation-evidence.tar.gz`.
It contains training configuration/logs, all checkpoint selection results, all
final trajectories and physical audits, sampled camera images, and source snapshots.
Selected weights are separate files `hotstab-ACT-selected.pt` and
`hotstab-DP-selected.pt`; their digests must match `selected/MODEL/selection.json`.
Absolute paths in historical invocation records document the original machine;
use your local paths when replaying commands. Do not overwrite recorded results.

```bash
.venv/bin/python scripts/evaluate_hotstab_checkpoint.py \
  --checkpoint DOWNLOAD/hotstab-ACT-selected.pt \
  --output-dir artifacts/hotstab_reproduction/ACT --split test \
  --ids $(seq 3000 3029) --record-video
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
  .venv/bin/python scripts/audit_hotstab_batch.py \
  --batch artifacts/hotstab_reproduction/ACT --workers 8
```

Repeat with DP. Run one Isaac simulator process at a time on this workstation.
The wrapper checks the complete fixed split and frozen source/checkpoint hashes.
Hardware or renderer versions can affect exact rendered bytes; the archived paired
expert replay records the observed RTX pixel variation. Physical trajectories were
exactly reproduced on the recorded environment, not guaranteed across all platforms.

The published policy videos show the first test state, not the most successful
state. They stop at that episode's recorded terminal boundary. Development expert
footage is labelled separately. Historical `hotstab-v1` prototype evidence belongs
to an older contact/controller revision and is not part of these scores.
