# HotStab ACT/DP v1 — frozen evaluation protocol

Task: recover a dropped protective dummy hot-stab on sand and return it to an
isolated service receptacle. No pressure, electrical connection, latch or granular
soil simulation. Scene based on ea19943, including the worn light tip marking. The collar contact
volume is partitioned into 32 triangular prisms to preserve its authored boundary
during collision cooking; dimensions, mass, inertia and contact materials are unchanged.

## Splits and controls

`states.json` contains all poses, generated before any learned-policy evaluation.
64 training states, 8 development/checkpoint states and 30 final test states.
Only plug reset x/y/yaw vary: x=0.65±0.04 m, y=0±0.025 m, yaw=±5 degrees;
z=0.032 m. Robot, socket, wall, gravity, mass, friction, currents and water are
unchanged. This is a bounded initial-pose benchmark, not water robustness.
The 30 test states are never used for gradients, normalization or checkpoint choice.
Expert attempts and failures are retained; unsuccessful demonstrations are excluded
from imitation training and explicitly counted. No test-driven scene or policy tuning.

Two fixed geometry-v2 cameras at 384×384, base and wrist, plus 8 measured normalized
robot coordinates (base XYZ, four joints, jaw). No object coordinates, contact state,
expert phase, success flags or future observation are policy inputs.
Images and proprioception precede the labelled command. Physics 240 Hz, control,
collection and policy action sequence 30 Hz. Absolute normalized actuator targets,
11-channel simulator interface losslessly packed into 8 channels with zero base
attitude commands. No 20/30 Hz interpolation in this benchmark.

## Gates before training

Run experts on development states, verify paired command replay from the same reset,
check camera timestamps and image/proprio/action alignment, and audit plug contact
geometry and the arm/wrist station proxies. The historical prototype's 0.594 mm
sand overlap is kept in its separate report. New demonstrations must pass the
unchanged 0.5 mm contact tolerance and the data timing checks. The collar partition
reduced the development resting-contact peak to 0.122 mm without changing its volume.
The dataset records this scene revision; historical demonstrations are excluded.

## Models and selection

One training seed (42) per architecture. Pinned repository ACT (LeRobot a16f34c)
and AM-Bench DP (60bf5b7), two camera inputs with shared image backbone within each
model, existing pretrained image encoders, no pretrained manipulation weights.
ACT: horizon 16, execute 8 actions then replan, ImageNet input normalization.
DP: horizon 16, two consecutive observations, execute 8 actions then replan,
CLIP-v2 preprocessing, 16 DDIM inference steps. Train-only normalization.
Initial training budget: ACT 10,000 updates; DP 4,000 updates; effective batch 32,
with microbatches as necessary. Intermediate checkpoints at one quarter of budget.
Select by development rollout successes, then lower development action prediction
error, then earlier checkpoint. Final independent 30-state evaluation for each selected
model, one rollout per state, 100 s horizon, first-episode censoring. Report all outcomes.
Low success is a valid result; no extra training seeds or relaxed physical criteria.

Matched-expert diagnostics report the first five consecutive frames with applied
target differences exceeding 2 cm in the base target vector, 0.03 rad in any arm
joint, or 0.5 mm in jaw-actuator stroke. Actual tool displacement is also compared
at a 1 cm / five-frame threshold. These development-defined diagnostic thresholds
do not alter task success or checkpoint selection. Teacher-forced predictions on
expert observations are reported separately from closed-loop task outcomes.

## Deliverables

Scene/source hashes, split manifest, verified collection/replay path, dataset manifest,
training configs and logs, selected weights and SHA256, per-test-state trajectories,
phase/failure diagnostics, fixed-camera expert and policy videos, reproducible commands,
website entry and GitHub release. Historical expert prototype evidence stays separate.
