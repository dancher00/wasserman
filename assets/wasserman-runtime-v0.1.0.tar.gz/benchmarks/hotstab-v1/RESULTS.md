# HotStab — final fixed-state evaluation

One training seed (42) per architecture. These are 30 independent test states, IDs 3000–3029. No test state selected a checkpoint or entered training. The expert uses privileged physical state; ACT/DP use the two fixed RGB cameras and measured robot coordinates.

| Method | Success / 30 | Physical audit / 30 | Successes passing physical audit |
|---|---:|---:|---:|
| expert | 28 | 30 | 28 |
| ACT | 2 | 30 | 2 |
| DP | 0 | 30 | 0 |

## Selection and failure outcomes

### ACT

Selected update 10000; development success 1/8. SHA256: `53dbdb69dfa13c83403b2e6dffc4a98b789cc334e1532dac5e848b47ae01f622`.

| Update | Development success | Development action L1 |
|---:|---:|---:|
| 2500 | 0/8 | 0.086030 |
| 5000 | 0/8 | 0.083297 |
| 7500 | 0/8 | 0.063616 |
| 10000 | 1/8 | 0.051908 |

Final test outcomes:

- `alignment_or_insertion_incomplete`: 5
- `dropped_after_lift`: 2
- `finger_contact_not_released`: 17
- `grasp_without_lift`: 1
- `no_verified_grasp`: 3
- `success`: 2

Initial proprioception maximum difference from the matching expert: 0. First sustained applied-target threshold crossings: steps 0–2; first sustained 1 cm tool deviations: steps 1–8.

### DP

Selected update 4000; development success 0/8. SHA256: `5572d160bec0c873f9f4f14a0333a88c6c2eabcde4332b64f995ba6330de5c38`.

| Update | Development success | Development action L1 |
|---:|---:|---:|
| 1000 | 0/8 | 0.513607 |
| 2000 | 0/8 | 0.216606 |
| 3000 | 0/8 | 0.127676 |
| 4000 | 0/8 | 0.077234 |

Final test outcomes:

- `grasp_without_lift`: 3
- `no_verified_grasp`: 27

Initial proprioception maximum difference from the matching expert: 0. First sustained applied-target threshold crossings: steps 0–23; first sustained 1 cm tool deviations: steps 1–29.

## Interpretation and limits

Expert command replay passed 8/8 with exactly matching commanded targets, measured state and plug trajectories. Both deployed policy interfaces matched direct preprocessing/history/normalization/action-queue calls exactly on 24 recorded observations with each selected checkpoint (replans at steps 0, 8 and 16; maximum command error 0). This supports the common execution path; it does not establish a unique cause for every learned-policy failure. Matched-time deviations identify when trajectories separate, not a causal diagnosis by themselves.

The benchmark varies only the bounded initial plug x/y/yaw. It does not measure water robustness. The receptacle is isolated; pressure, electrical mating, seals and latching are outside this task. Sand is a rigid compacted floor. Physical audits are sampled at 30 Hz and have explicit geometric scope; they are not a proof of absence of all substep or self-collisions. Success remains the frozen insertion, release, withdrawal and two-second unsupported hold criterion.

See [PROTOCOL.md](PROTOCOL.md), [RESTORE.md](RESTORE.md), and per-state records under `results/`. Historical prototype evidence remains separate.

## Expert baseline failures

- State 3012: `lost_grasp_before_seating`. Event steps: `{'grasped': 303, 'lifted': 436, 'seated': None, 'success_after': None}`.
- State 3025: `grasp_without_lift`. Event steps: `{'grasped': 280, 'lifted': None, 'seated': None, 'success_after': None}`.

## Observation checks and teacher-forced imitation

Teacher forcing supplies recorded expert observations at every step while retaining the deployed eight-step action queue. It measures prediction error without simulator feedback; it is not an additional task-success evaluation. Errors below are scaled by training-set action standard deviation, averaged over channels and time. DP stochastic samples need not equal those consumed during a simulator rollout.

| Model | Initial base RGB max MAE / 255 | Initial wrist RGB max MAE / 255 | Teacher-forced action error |
|---|---:|---:|---:|
| ACT | 0.000000 | 0.092803 | 0.050008 |
| DP | 0.000000 | 0.109669 | 0.078851 |

The action-prediction error already exists on expert observations. Closed-loop trajectories then visit different states. This is consistent with accumulating imitation/control errors, but no intervention establishes a unique cause for all failures. The measured results do not rank the architectures beyond this dataset, training budget and single seed.

Two selected-policy development examples (state 1000, post-action step 1400): [ACT holding the inserted plug](diagnostic-images/ACT_10000-base-state1000-step1400.png), [DP positioned over the body ahead of the handle](diagnostic-images/DP_4000-wrist-state1000-step1400.png). These are labelled development diagnostics, not extra test successes.

## Physical audit detail

- expert: maximum sampled plug/floor overlap 0.1876 mm; plug/receptacle overlap 0.1183 mm. States failing the physical audit: [].
- ACT: maximum sampled plug/floor overlap 0.4120 mm; plug/receptacle overlap 0.1818 mm. States failing the physical audit: [].
- DP: maximum sampled plug/floor overlap 0.4120 mm; plug/receptacle overlap 0.0000 mm. States failing the physical audit: [].

The fixed tolerance is 0.5 mm. Audit flags are reported separately from the environment success predicate; neither tolerance nor success conditions were changed after observing test outcomes. Full arm/wrist/finger proxy results and geometric scope are in the per-episode audit files.
