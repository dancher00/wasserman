# HotStab benchmark v1

Completed fixed-state benchmark: **expert 28/30, ACT 2/30, DP 0/30**.
All 90 final episodes passed the stated physical audit. ACT usually fails to release
the seated plug; DP usually fails to establish the grasp. These are measured baselines,
not reliable deployed policies. See [RESULTS.md](RESULTS.md) for every outcome,
checkpoint selection, trajectory divergence and remaining limitations.

[GitHub release: weights, lossless dataset, trajectories and videos](https://github.com/dancher00/wasman/releases/tag/hotstab-act-dp-v1).
[Restore and reproduce](RESTORE.md). Training used 59 audited successful demonstrations
from 64 attempts, one seed per architecture, and eight separate development states.
Expert development and paired command replay passed 8/8 each.

See [PROTOCOL.md](PROTOCOL.md) for the frozen splits, input contract and selection rule,
and [EXPERT_DIAGNOSIS.md](EXPERT_DIAGNOSIS.md) for the diagnosed shallow-grasp failure.

The task is to retrieve a dropped protective dummy hot-stab from compacted sand,
insert it into an isolated subsea service receptacle, open the gripper, and withdraw.
The original standard wall and fixed robot cameras are retained. The collar has an
exact partition of the same collision volume; the visible handle has not been reshaped.

## Collection and validation

Run from the repository root with the existing IsaacLab/PhysX virtual environment.
The locally installed robot CAD assets are required; their checksums are recorded,
without redistributing the original CAD in source archives.
The pinned policy dependencies can be installed with
`.venv/bin/python scripts/bootstrap_visual_policies.py` and verified with `--check`.
Exact runtime versions and dependency commits are in `environment.json` and
`python_environment.txt`; the existing root README describes runtime/CAD installation.

```bash
.venv/bin/python scripts/run_hotstab_episode.py \
  --output-dir artifacts/hotstab_v1/benchmark_final/data/development00 \
  --split development --ids 1000 1001 1002 1003 1004 1005 1006 1007 \
  --mode expert --collect --record-video
.venv/bin/python scripts/run_hotstab_episode.py \
  --output-dir artifacts/hotstab_v1/benchmark_final/replay/development00 \
  --split development --ids 1000 1001 1002 1003 1004 1005 1006 1007 \
  --mode replay --replay-dir artifacts/hotstab_v1/benchmark_final/data/development00
.venv/bin/python scripts/audit_hotstab_batch.py \
  --batch artifacts/hotstab_v1/benchmark_final/data/development00
.venv/bin/python scripts/audit_hotstab_batch.py \
  --batch artifacts/hotstab_v1/benchmark_final/replay/development00 \
  --reference artifacts/hotstab_v1/benchmark_final/data/development00
```

Output directories must be fresh. Do not mix old prototype data with this scene.
Training states 2000–2063 use the same runner with `--split train --collect`.
Each episode records pre-action RGB, proprioception and absolute actuator commands
at 30 Hz; post-action physical diagnostics are labelled separately.
Only successful, audited training demonstrations enter the dataset.

## Learning and evaluation

After collection, physical audits and paired replay have passed:

```bash
.venv/bin/python scripts/train_hotstab.py \
  --data artifacts/hotstab_v1/benchmark_final/data \
  --output-dir artifacts/hotstab_v1/benchmark_final/training/ACT --model ACT
.venv/bin/python scripts/train_hotstab.py \
  --data artifacts/hotstab_v1/benchmark_final/data \
  --output-dir artifacts/hotstab_v1/benchmark_final/training/DP --model DP
```

Evaluate the four saved checkpoints on development states with
`evaluate_hotstab_checkpoint.py --checkpoint PATH --output-dir PATH --split development --ids ...`.
This wrapper records the checkpoint checksum and invocation around the frozen runner.
Use output names `ACT_2500` through `ACT_10000` and `DP_1000` through `DP_4000`.
`select_hotstab_checkpoint.py --training PATH --evaluations PATH --output-dir PATH`
requires all four complete development evaluations and freezes the selected weight.
Then evaluate IDs 3000–3029 with the same wrapper and `--split test`.
No extra training seeds and no selection using test outcomes.

`summarize_hotstab_evaluation.py` records per-state physical failure categories and
matched-time deviations from the expert. `diagnose_hotstab_teacher_forcing.py`
separately measures predictions on expert observations with the normal action queue;
this distinguishes imitation error from the additional error during closed-loop execution.

## Dataset transfer

Raw training RGB is transported as lossless `libx264rgb` video, not the lossy website
recordings. Every encoded camera stream is decoded and checked against the original
raw SHA256 before packaging. `transport_hotstab_dataset.py --mode restore` recreates
the exact RGB bytes and checks them again. Extract all dataset tar parts into one
directory, then restore each `encoded/development00`, `encoded/train00` and
`encoded/train01` into the corresponding subdirectory of the training data root.
The original per-episode metadata, commands, audit results and camera snapshots are retained.

`manifest_hotstab_dataset.py --data PATH` freezes checksums for every episode and
lists both accepted and excluded attempts. The incomplete native RTX-crash run is
outside this dataset. Completed replacement episodes use the same initial states,
scene and controller. The incomplete run remains outside the reported 64 completed training attempts.

Historical single-state prototype evidence at `website/public/static/hotstab-v1`
predates the collision-contact correction and must not be presented as these results.
