# Rapid valve commands: three matched demonstrations

One hand, one hand with a support grasp, and two hands turning the wheel.
A single matched reset (93003), 50 seconds per mode. These recordings are a
stress demonstration, **not a new task-success benchmark** and not a rollover demonstration.

The command requests one 90° turn at 1.4 rad/s (20× the benchmark's 0.07 rad/s).
Grasp acquisition is retained; the end-of-turn convergence guard is removed so
that failure to follow the rapid command remains visible. The arm then holds,
releases and withdraws. Mass, inertia, hydrodynamics, station keeping, valve
friction, native drives and 1540 N thruster limits are unchanged. Requested speed
must not be confused with measured wheel speed.

| Mode | Peak orientation error | Peak tilt from vertical | Maximum wheel angle | Peak thruster load |
|---|---:|---:|---:|---:|
| One hand | 3.285° | 2.616° | 86.977° | 43.293% |
| One hand + support | 10.632° | 10.563° | 35.107° | 69.013% |
| Two hands on valve | 8.525° | 7.778° | 29.416° | 64.538% |

All metrics cover the complete 50 seconds, not a selected segment. None overturns.
This one reset cannot establish a general ranking of the modes.

**Audit limitation:** the two-hands trace exceeds a native joint limit by
0.002357679 rad (0.135°), exceeding the existing 0.002 rad audit tolerance.
It is preserved and displayed as a failure diagnostic, not certified as a clean
benchmark episode. The other two pass this tolerance. All three have zero detected
CAD self-collisions, remain below motor force caps and reproduce tool positions
within 1.6 µm. The `independent-replay.json` task-success flags are false because
this intentionally requests only 90°, while task success requires 170°.

## Reproduce

Use the environment from the [bimanual reproduction guide](../../docs/studies/bimanual-valve-v1-reproduction.md).
The new modules are additive; the v1 physical sources and results remain frozen.

```bash
python scripts/probe_bimanual_fast_turn.py --fixture large --mode free \
  --seeds 93003 --seconds 50 --dt 0.004166666666666667 --solver-type 0 \
  --feedback-frame level --spawn-fixture-at-reset-pose --grasp-effort 4 \
  --output-dir artifacts/fast-valve/free
python scripts/analyze_bimanual_trace.py artifacts/fast-valve/free
python scripts/audit_bimanual_trace.py artifacts/fast-valve/free
python scripts/render_bimanual_presentation.py --run artifacts/fast-valve/free \
  --output-dir artifacts/fast-valve/free/pool-render --wide --pool-depth 3
```

Repeat with `support` and `two-hands`, then run `scripts/report_bimanual_fast_turn.py
--root artifacts/fast-valve --output artifacts/fast-valve/summary.json`.
The reducer exposes the failed joint-limit audit rather than dropping that run.

The fixed wide camera reconstructs recorded states at real time, 720p/30 fps,
without audio or overlays. The pool is 3 m deep to contain the complete robot
throughout these trajectories. Pool depth is a presentation setting, not a new
fluid model. Cosmetic steel flanges, welds, bolts and braces preserve the exact
support grasp cylinder. They do not add contacts or change dynamics. The regular
180-second benchmark films retain the original 2.5 m presentation pool.

[Versioned recordings and evidence](https://github.com/dancher00/WasserMan-Bench/releases/tag/bimanual-fast-turn-v1).
The release is private; sign-in is required.
