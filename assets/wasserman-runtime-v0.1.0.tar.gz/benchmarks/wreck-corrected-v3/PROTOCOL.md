# Corrected-scene ACT/DP comparison

Started from 749c0c0 with a clean worktree; no user changes needed preservation.
Training random seed: 42 only. No physics, success-contract or task-scope relaxation.
Historical data/results remain separately labelled in their original directories.

Cargo: diagnose the selected ACT residual, DP CLIP absolute and DP CLIP residual failures on validation seeds 6028,6033,6040,6051. Expert-prefix interventions are diagnostics, never autonomous scores. No long retraining before evidence establishes its reason. Freeze final architecture/checkpoint selection on development data before final tests. Final seeds 8000–8029 exclude training/validation and all historically inspected test states 7000–7029. The new list was frozen before any final evaluation launch.

Cabin: old training episodes predate native door-sheet collision, enabled hinge collisions and continuous cabinet handle. They are not accepted as current-scene data. Revalidate current expert on development resets, including door and HDD/hinge trajectory audits. Collect fresh version-hashed data with per-episode audit records before training. Separate checkpoint validation from final seeds 8000–8029. Keep unsuccessful collection attempts and exclude them explicitly from successful-demonstration training.

Deliver per-seed first-episode outcomes (no resets), failure diagnosis, videos, selected weights, configs, source/scene hashes and reproducible execution commands. Low success is a valid measured result. Completion requires both final 30-state ACT/DP evaluations; intermediate diagnostic success does not qualify.

## Episode-boundary accounting

CargoRelease's timeout condition is `episode_length_buf >= max_episode_length - 1`. With one warmup control step, the requested2698-step final run reaches that terminal boundary on its last call. The evaluator excludes terminal/reset frames from success and physical-progress scoring and never scores subsequent episodes. Inactive environments can continue stepping inside the vectorized simulator while other trials finish; all of their later frames are discarded. Thus at most2697 nonterminal policy frames (89.9s) are scored. Retain the original terminal records; a terminal boundary is not a successful reset/retry. CabinRecovery inherits the 150s timeout and uses4498 policy steps after one warmup. This clarification changes neither simulation nor success thresholds.

Fresh Cabin data also reuse the existing untouched-HDD stability audit during the complete door-clear/standoff phases5–6: peak-to-peak position≤0.5 mm, linear speed≤5 mm/s, angular speed≤0.05rad/s, finger contact<0.08 N. This is a data-quality gate inherited from the historical protocol; task success remains unchanged. Incomplete rest evidence or failed contact audits exclude a demonstration from training while preserving the attempted episode.
