# Corrected wreck ACT/DP comparison

|Task|Policy|Success|Exact 95% interval|
|---|---|---:|---:|
|CargoRelease|ACT|3/30|2.1%–26.5%|
|CargoRelease|DP|1/30|0.1%–17.2%|
|CabinRecovery|ACT|0/30|0.0%–11.6%|
|CabinRecovery|DP|0/30|0.0%–11.6%|

Cabin geometry is reported separately; the task success contract is unchanged.

|Policy|Door/hinge audit passes|Task successes also passing the audit|
|---|---:|---:|
|ACT|27/30|0/30|
|DP|30/30|0/30|

Geometry audit: recorded 30 Hz control frames; unchanged 0.5 mm contact tolerance. Not physics substeps.

One training seed per selected run; intervals describe reset-state variation only.
New fixed states 8000–8029 exclude historical inspected test states 7000–7029.
Calm water and robot flashlights only. Water-appearance videos are not a policy robustness evaluation.
Historical CabinRecovery data are excluded from the corrected-scene training set.

Per-seed outcomes and hashes are in results.json.
