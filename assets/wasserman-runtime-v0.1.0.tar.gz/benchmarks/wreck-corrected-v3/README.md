# Corrected wreck ACT/DP comparison

Completed fixed-budget, single-training-seed comparison on corrected scenes.
Both policies use the same 30 independently reserved reset states per task
(8000–8029), separate from training, checkpoint selection and historical tests.

| Task | ACT | DP |
|---|---:|---:|
| CargoRelease | 3/30 | 1/30 |
| CabinRecovery | 0/30 | 0/30 |


See [complete results and uncertainty](REPORT.md), [every episode](results.json),
[CargoRelease diagnosis](CARGO_DIAGNOSIS.md), and
[CabinRecovery diagnosis](CABIN_DIAGNOSIS.md). Geometry quality is reported
separately from the unchanged task success contract; failed or unverified
geometry audits are not silently removed from the denominator.

CabinRecovery uses 80 fresh, quality-audited demonstrations: 76 training and four
validation episodes. Collection retained all 160 attempts, including failures
and audit rejections. Old-scene recordings are excluded. The accepted expert
passes all four development states and expert-command replay succeeds 12/12.
CargoRelease retains validation-selected residual ACT/DP checkpoints after
its pipeline and approach diagnostics; no additional Cargo training was run.

The scene physics, assets and success criteria are byte-identical to the starting
commit 749c0c0; [source comparison](unchanged_physics_and_contracts.json).
Cabin's expert trajectory was corrected to clear the hinge during withdrawal.
[Protocol](PROTOCOL.md), [checkpoint selection](cabin_selected_weights.json),
[Cargo selection](cargo_final_selection.json), and
[matched initial inputs](matched_initial_inputs.json) preserve evaluation boundaries.

[Release: weights, evidence and videos](https://github.com/dancher00/wasman/releases/tag/wreck-corrected-v3)
includes the four exact selected weights, configurations, source/data hashes,
per-episode trajectories, failed-development evidence and SHA256SUMS.
[Reproduction commands](REPRODUCTION.md) run the independent evaluation without
training RGB. Raw RGB remains local; its omission and regeneration limits are
explicit. Histories remain in the versioned v1/v2 folders.

Training RNG seed 42 only; ACT 20,000 updates and DP 10,000 updates. This is not
an exhaustive convergence study. Water is calm and illumination comes only from
robot flashlights. Water-appearance expert demos are separate from policy
robustness evaluation. π₀ and additional training seeds remain outside scope.
