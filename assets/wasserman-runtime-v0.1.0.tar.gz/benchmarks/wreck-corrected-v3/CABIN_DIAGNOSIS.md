# CabinRecovery: current-scene data and expert validation

Model training, independent evaluation and recorded-trajectory geometry audits are complete. The
expert results below are development checks, not learned-policy scores.

## Old data are not current-scene demonstrations

The inventory found 80 historical RGB episodes. Their cabinet/controller hashes
differ from the corrected scene at 749c0c0; none is admitted automatically.
The new-handle expert film is evidence for its own recorded trajectory, not a
replacement for a current training dataset. The inventory and original hashes
are preserved in `cabin_data_inventory.json`.

Fresh v2 recordings include robot and payload poses, velocities, contact forces,
expert command targets and phases, synchronized wrist RGB and source hashes.
Training loaders reject the historical schema, pending/failed quality checks and
mixed source versions. The image and measured state precede the command; physical
outcomes are recorded after it. The command interface remains normalized absolute
base position, four arm joints and jaw, with level base attitude.

## Expert changes address measured failures

The first current-scene gate completed two of four episodes within its
140-second observation window. One successful episode exceeded the 0.5 mm hinge
intersection tolerance. Another episode stayed at the HDD standoff: measured
position error was 16.67 mm against the expert's 14 mm transition condition.
These are retained as `cabin_gate_current_*.json`; the shorter window is not
reported as a full 150-second task evaluation.

Reducing the secondary posture preference from an effective gain of 0.30 to 0.05
only during HDD manipulation completed all four development states before
121 seconds. However, seed 43 reached 1.052 mm HDD/hinge overlap during the start
of outward withdrawal. Therefore this candidate was not used for collection.
Its measured outcomes and failed geometry check remain in
`cabin_gate_posture005_*.json`.

The accepted expert first lifts the grasped disk 5 cm along cabinet +Y, away from
the supporting side panel of the toppled cabinet. It then follows the original
outward extraction vector. The lift advances at 15 mm/s and must reach its
tracking condition before outward motion starts. This is ordinary robot
actuation: the expert does not reposition the HDD, attach it to the fingers or
apply a target-dependent force to it. The scene, hydrodynamics, masses, collision
geometry, friction and task success contract remain unchanged.

| Development state | Full success | Control frames | Peak HDD/hinge overlap | Peak arm/door proxy overlap |
|---|---|---:|---:|---:|
|42|Yes|3629|0.450 mm|0 mm|
|43|Yes|3793|0.435 mm|0.335 mm|
|44|Yes|3660|0.428 mm|0 mm|
|45|Yes|3690|0.452 mm|0 mm|

All four pass the existing 0.5 mm geometry tolerance. The untouched HDD also
passes the existing rest-stability audit throughout door-clear and standoff
phases: no recorded position excursion, no fingertip contact, and velocity below
the fixed limits. Full numeric reports and source hashes are in
`cabin_gate_clearance005_*.json`; the complete state-42 wrist video is
`website/public/static/wreck-corrected-v3/cabin_expert42.mp4`.

These geometry audits inspect every recorded 30 Hz control frame, not every
240 Hz physics substep. The arm/door audit covers arm/wrist CAD and collision
proxies; intended finger/handle contacts and other furniture are outside that
specific audit. Small reported overlaps are numerical contact tolerances, not
claims of exact zero intersection.

## Fresh data and independent evaluation

Collection uses the accepted source version and retains every attempted seed.
Only successful episodes passing door, hinge and untouched-HDD stability checks
are eligible; the first 80 eligible episodes form the fixed cohort. The split is
76 training / 4 validation with RNG seed 42 for both models. Expert-command
replay checks the data transport before learning. Selected checkpoints are frozen; final outcomes are recorded after execution.

The final states 8000–8029 are separate from training, checkpoint selection and
historical inspected test states. A learned policy's geometry audit is reported
separately from the unchanged task success contract, so neither a model failure
nor an unwanted contact is silently removed from its 30 trials.

## First collection batch and rejected recordings

The first 96 attempts produced 94 task successes and two horizon failures
(states 6004 and 6008, cabinet opening). Only 54 episodes pass every unchanged
quality gate. The full per-episode records are in `cabin_batch000_contacts.json`.
Failures overlap: 17 recordings exceed the existing 10 µm URDF/base reconstruction
check, 15 additional recordings fail the arm/door proxy tolerance, 14 fail the
HDD/hinge tolerance, and the two opening failures lack pre-grasp rest evidence.
No rejected recording is admitted to training merely because task success was true.

The kinematic mismatch peaks at 12.062 µm in outer cells of the 96-scene grid.
Its measured axis-wise errors and world positions are preserved in
`cabin_batch000_fk_diagnosis.json`. The 10 µm consistency guard and 0.5 mm contact
tolerance are retained. The batch wrapper now records a per-episode audit
rejection instead of aborting the entire cohort on the first rejected recording;
source-version mismatches still stop the batch. Auditing was rerun on the same
unaltered recordings. A second batch of 64 states continues the predeclared
maximum of 160 collection attempts; this is not an additional training RNG seed.

## Completed collection and frozen split

The second batch completed 64/64 tasks; 48/64 pass the unchanged quality audits.
No second-batch recording fails the 10 µm kinematic consistency guard. The
remaining rejections are eight arm/door and nine HDD/hinge tolerance failures,
with one episode in both groups. Across both batches: 158 task successes from
160 attempts; 102 quality-accepted demonstrations; the first 80 are selected.
The other 22 eligible episodes and all 58 rejected attempts remain preserved.

Before training, `cabin_split_frozen.json` fixes the exact cohort and its metadata
hashes. Both models use 76 training episodes and validation states 6057, 6062,
6075 and 6091. Final states remain 8000–8029. `cabin_source_version.json` pins the
current collector, controller and scene sources. Selection never consults a
learned model's final test outcomes.

## Current-scene command replay

On the four frozen validation states, raw actuator30 Hz, packed actuator30 Hz and
packed actuator targets resampled through20 Hz each complete4/4 episodes. Total:
12/12 with zero resets, in 3689 control steps. This is a recording/transport check,
not a learned-policy score. The complete replay trace is retained and the numeric
summary is `cabin_expert_replay_12of12.json`.

The complete data audit verifies 80 selected episodes and 195951 logical20 Hz
observation windows. Recorded camera times match the reconstructed native
float32 clock exactly. Packed targets equal the recorded expert actuator targets;
base attitude channels are zero as required by this interface. Both actual
training configs have been checked against the pre-training split and source
manifest. No final test state participates in training or checkpoint selection.

A separate scan of the existing door-audit records confirms zero arm/wrist CAD
triangle crossings of the finite door mid-plane across all 80 selected episodes
(and all four current expert gate states). This uses the same recorded 30 Hz poses,
not new simulated trials. Counts are preserved in
`cabin_selected_cad_door_checks.json`; intended finger/handle contacts remain
outside the arm/wrist CAD audit.

The paired TCP trajectory comparison adds a quantitative transport reference:
median replay/expert position errors range from 0.090 to 0.201 mm, with a largest
recorded deviation of 7.809 mm across all twelve runs. None reaches the 1 cm
threshold used to locate substantial model divergence. The traces differ
slightly despite matching reset seeds and commands; replay success is not a
claim of bitwise identical contact dynamics. See `cabin_replay_vs_expert.json`.

## Frozen learned checkpoints and offline errors

Both trainings are complete, with one RNG seed (42) and the frozen 76/4 split.
ACT's 20,000-update checkpoint minimizes full-validation inference action L1:
0.05679846 (earlier 5k/10k/15k checkpoints: 0.08625850/0.07517782/0.07024603).
DP's 10,000-update checkpoint minimizes full-validation diffusion loss:
0.01260781 (earlier validation values: 0.01551822/0.01325089/0.01291412).
These different objectives cannot be compared directly as policy quality.
The exact selected files and SHA-256 hashes are in `cabin_selected_weights.json`.
Selection precedes all physical learned-policy validation and final testing.

Teacher-forced predictions on the four validation recordings give first-target
base-position median errors of 1.775 mm for ACT and 3.011 mm for DP across sampled
frames. Within the first second, the medians are larger: 5.805 mm and 23.948 mm,
respectively (12 sampled observations per method). The largest first-second
errors are 10.892 mm and 62.206 mm. Thus global offline averages conceal startup
errors. Normalization round trips are within 1.2e-7 normalized units.
These checks use expert images/states, not observations caused by model actions;
they cannot establish closed-loop success. DP's sampled noise stream also differs
from the physical rollout's batch, so these are not identical predictions.
Numeric evidence is retained in `cabin_*_teacher_predictions.json` and
`cabin_teacher_start_errors.json`.

## ACT physical validation and first-image intervention

ACT completes 0/4 full-horizon validation episodes. None satisfies cabinet
opening under the contact-based contract; state 6075 reaches the handle and
briefly moves the door (maximum 2.05°), while the other three never reach the
required handle neighborhood. All four remain in their first episode.
Initial normalized robot-state differences from the expert are at most 5.41e-6.
The first sustained TCP separation above 1 cm occurs after 4–6 control steps
(0.13–0.20 seconds), well before the opening failure.

At the initial state, base-target errors against the expert are 35.5, 28.1,
25.5 and 29.3 mm. They exceed the teacher-forced startup errors. To distinguish
input sensitivity from transport/normalization and inference batching, the
saved first image of validation state 6057 was passed through the same frozen
ACT again. It reproduces the physical run's first base target within 0.148 mm
(batch four) and exactly for the base channels in a single-image batch.
Replacing only that image with the expert's initial image reduces error against
the expert target from 35.5 mm to 5.84 mm. Repeating the expert inputs in a batch
of sixteen changes this error by less than 0.04 mm.

The full-frame raw image difference is only 0.471/255 mean intensity, but this
average hides visibly different highlights in an otherwise very dark wrist
view. Thus a low image MAE does not establish policy-equivalent observations.
The saved-frame intervention establishes first-command image sensitivity;
it does not establish the source of the renderer difference or show that
replacing images throughout an episode would solve the task. Collection and
evaluation use the same camera profile, resolution, RTX configuration and
warmup sequence, but different vectorized scene placements/counts. No render
or illumination setting is adjusted using final test outcomes.
See `cabin_ACT_initial_image_intervention.json` and the repeatable diagnostic
script of the same name in `scripts/`.

## DP physical validation

DP also completes 0/4 validation episodes without any reset. Three states fail
the cabinet-opening stage. In state 6075, the unchanged contact-based opening
criterion is reached at step 1404; opposing HDD finger contacts are recorded
at step 1909. The disk is not extracted and no continuous success hold begins.
An instantaneous opposing-contact event is not complete HDD recovery.

The first base-command errors are 65.5, 31.5, 33.6 and 49.6 mm for states 6057,
6062, 6075 and 6091. Sustained TCP divergence above 1 cm starts at steps 3, 9, 9
and 3 (0.10–0.30 seconds). Initial measured states agree with the expert to the
same tolerance as ACT, and ACT/DP's saved initial RGB for state 6057 is identical.
The frozen model's early approach errors precede cabinet/HDD manipulation.
The ACT image intervention is not extrapolated to DP as a measured causal claim;
DP's stochastic predictions and subsequent closed-loop trajectory are retained
in their own evidence. No learned-policy weights or evaluation settings are
changed after these validation runs.

## Independent final states 8000–8029

ACT: **0/30 full successes**. Failure stages: approach/grasp/open cabinet: 24; approach/grasp/extract HDD: 6. Early terminal states: none. Recorded door/hinge audits pass for 27/30 episodes; 0/30 satisfy both task success and the audit.

DP: **0/30 full successes**. Failure stages: approach/grasp/open cabinet: 29; approach/grasp/extract HDD: 1. Early terminal states: none. Recorded door/hinge audits pass for 30/30 episodes; 0/30 satisfy both task success and the audit.

These outcomes were measured with frozen weights and unchanged evaluation settings.
No final state was used to choose a checkpoint, tune actions, change illumination,
or alter physics/success criteria. Videos use the predeclared state 8000, regardless
of outcome. Every first-episode result and failure stage is retained in the
`cabin_*_fixed30_*.json` files. Geometry reports preserve separate door/hinge failures
and reconstruction errors; a failed verification is not claimed to be proof of an
intersection. The audits sample control frames, not every physics substep.

Three ACT final trajectories fail the door audit: states 8014, 8016 and 8019.
Their peak arm/wrist proxy overlaps with the door sheet are 1.739, 1.707 and
1.694 mm respectively, above the unchanged 0.5 mm tolerance. The corresponding
CAD door-midplane crossing counts are 106, 75 and 117 recorded link/frame entries.
These are measured geometry violations, not only unverifiable reconstruction.
All three already fail task success. They remain failures in the 30-state cohort;
no threshold or collision setting was adjusted after observing them. All 60
HDD/hinge checks pass; DP also passes all 30 door checks. The scene's enabled
colliders therefore do not justify a claim that every learned motion is free of
penetration. These residual model-trajectory contact failures remain explicit
limitations of the measured comparison.
