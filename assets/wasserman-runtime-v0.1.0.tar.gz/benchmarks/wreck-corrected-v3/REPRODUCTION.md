# Reproduce the corrected-scene comparison

Use this branch at the release commit, not the historical v1 benchmark drivers.
Install the pinned simulator and visual-policy dependencies described in the
repository README and `docs/openchest-second-machine.md`. Reach Alpha visual
meshes require the separately licensed local assets described there. Exact
installed package versions, dependency revisions and GPU driver are recorded in
`environment.json`. These measurements used one RTX 5090.

The `wreck-corrected-v3` release contains four exact selected checkpoints,
`manifest.json`, `SHA256SUMS`, an evidence archive and a video archive.
Download its assets into `checkpoints/exported/wreck-corrected-v3/`
and verify them with `sha256sum -c SHA256SUMS` from that directory.

## Independent evaluation

Run from the repository root in the pinned `.venv`. Each output directory must
be new. These commands use only wrist RGB and measured robot state at inference;
no expert state or training RGB is required. Run the simulator jobs sequentially.
The fixed 30 states are identical for ACT and DP within each task.

```bash
.venv/bin/python scripts/evaluate_rope_visual.py \
  --checkpoint checkpoints/exported/wreck-corrected-v3/CargoRelease_ACT.pt \
  --output-dir artifacts/rope_reproduction_v3/ACT_fixed30 \
  --seeds {8000..8029} --steps 2698 --record-video
.venv/bin/python scripts/evaluate_rope_visual.py \
  --checkpoint checkpoints/exported/wreck-corrected-v3/CargoRelease_DP.pt \
  --output-dir artifacts/rope_reproduction_v3/DP_fixed30 \
  --seeds {8000..8029} --steps 2698 --record-video
.venv/bin/python scripts/evaluate_cabin_visual.py \
  --checkpoint checkpoints/exported/wreck-corrected-v3/CabinRecovery_ACT.pt \
  --output-dir artifacts/cabin_reproduction_v3/ACT_fixed30 \
  --seeds {8000..8029} --steps 4498 --record-video
.venv/bin/python scripts/evaluate_cabin_visual.py \
  --checkpoint checkpoints/exported/wreck-corrected-v3/CabinRecovery_DP.pt \
  --output-dir artifacts/cabin_reproduction_v3/DP_fixed30 \
  --seeds {8000..8029} --steps 4498 --record-video
```

The evaluator checks Cabin data-source hashes against the checked-out scene and
collector. A mismatch is an error, not permission to evaluate a different scene.
The Cargo evaluator records its source hash and checkpoint identity; use the
release source and compare `cargo_current_source_audit.json`. PhysX contact
trajectories can differ with hardware/runtime versions; a matching seed alone
is not a promise of bitwise identical dynamics.

Success is first-episode task success. Terminal/reset frames and every later
frame are excluded, even when inactive environments continue stepping within a
vectorized simulator. The exact horizon accounting is in `PROTOCOL.md`.
Cabin geometry quality is reported independently of task success:

```bash
.venv/bin/python scripts/audit_cabin_policy_contacts.py \
  --rollout artifacts/cabin_reproduction_v3/ACT_fixed30/rollout.pt \
  --output artifacts/cabin_reproduction_v3/ACT_contacts --workers 4
```

Repeat that audit for DP. Audit samples are recorded control frames at 30 Hz;
they do not establish absence of every possible physics-substep intersection.

## Data and training provenance

Old Cabin demonstrations are incompatible with the corrected scene. Fresh
collection records source hashes, keeps failed attempts and admits only
successful, quality-audited trajectories. `collect_corrected_cabin_dataset.py`
collects the cohort; `run_corrected_cabin_learning.py` verifies expert command
replay, fixes the shared train/validation split, trains one random seed (42),
selects on validation only and evaluates ACT/DP on the independent states above.
Its recorded `progress.json` contains the actual commands. The release evidence
contains the selected data hashes and every attempt's quality metadata.

Raw RGB training data remain local and are not part of the release. Regeneration
is possible from recorded collection commands and source, subject to simulator
nondeterminism; it is not a byte-identical substitute for downloading those raw
recordings. Cargo uses the previously trained, validation-selected residual
checkpoints: no new training followed inspection of final states8000–8029.

π₀, additional training seeds and water-randomized policy evaluation are outside
this comparison. Water-appearance expert videos are a separate demonstration.

## Recheck the paired diagnostics without full training RGB

The evidence archive includes the four validation experts' command/pose records,
lossless first-frame PNGs, the models' validation rollouts, and recorded prediction
arrays. Paths below assume the evidence archive was extracted in the repository
root. Fresh output paths are required.

```bash
.venv/bin/python scripts/check_cabin_visual_replay.py \
  --episodes evidence/CabinRecovery/validation_expert/train_batch*/seed_* \
  --output-dir artifacts/cabin_command_reproduction_v3
.venv/bin/python scripts/diagnose_cabin_closed_loop.py \
  --rollout evidence/CabinRecovery/ACT/validation/rollout.pt \
  --data evidence/CabinRecovery/validation_expert \
  --output artifacts/cabin_ACT_paired_reanalysis_v3.json
.venv/bin/python scripts/diagnose_rope_closed_loop.py \
  --rollout evidence/cargo_development/rope_ACT_residual_selected_physical/rollout.pt \
  --data evidence/CargoRelease/validation_expert \
  --output artifacts/cargo_ACT_paired_reanalysis_v3.json
```

The diagnostic readers use the lossless initial PNG when the continuous
`wrist.rgb` file is absent. Both task examples were checked: that PNG equals the
raw first frame exactly. Recomputing new predictions at every validation image
still requires the original RGB recordings; the published prediction arrays
support reanalysis of the reported sampled errors without those streams.

Training is a fixed-budget comparison, not a claim of exhaustive convergence:
ACT uses 20,000 optimizer updates, DP uses 10,000, and each uses one training RNG
seed (42). Checkpoint selection uses the stated full-validation metric. Budgets,
nominal learning-rate schedule and actual checkpoint step are retained in the
individual configurations and training logs.

The expert/replay TCP comparison is also directly repeatable from the evidence:

```bash
.venv/bin/python scripts/diagnose_cabin_command_replay.py \
  --replay evidence/validation_command_replay/replay.pt \
  --data evidence/CabinRecovery/validation_expert \
  --output artifacts/cabin_replay_vs_expert_reanalysis_v3.json
```

After rerunning both methods on each task, verify their matched initial robot
states, control clocks and recorded initial images:

```bash
.venv/bin/python scripts/verify_corrected_wreck_inputs.py \
  --cargo artifacts/rope_reproduction_v3 --cabin artifacts/cabin_reproduction_v3 \
  --output artifacts/wreck_initial_inputs_reproduction_v3.json
```

The ACT first-image intervention requires only the saved validation PNGs and
commands (no continuous RGB or simulator):

```bash
.venv/bin/python scripts/diagnose_cabin_initial_image.py \
  --checkpoint checkpoints/exported/wreck-corrected-v3/CabinRecovery_ACT.pt \
  --rollout evidence/CabinRecovery/ACT/validation/rollout.pt \
  --data evidence/CabinRecovery/validation_expert \
  --output artifacts/cabin_initial_image_reanalysis_v3.json
```
