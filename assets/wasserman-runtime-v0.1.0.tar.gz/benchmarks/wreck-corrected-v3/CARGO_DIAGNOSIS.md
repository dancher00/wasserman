# CargoRelease: failure localization before final tests

The remaining measured failure is inaccurate learned approach/alignment before severance. It is not a broken actuator replay or a changed cutting criterion. No new long training run was started in this stage.

## Paired evidence

All comparisons use validation states 6028,6033,6040,6051, excluding final test states. Initial measured state agrees with the recorded expert within roughly 1e-6 normalized units. The saved initial camera for seed 6028 differs from its dataset frame by only 0.084927 mean intensity on a0–255 scale. That image comparison is for the saved first environment, not a claim of pixel identity across the entire trajectory. Camera position/profile, pre-action timing, transforms, normalization and coordinate transport are separately checked in [the preceding pipeline audit](../../docs/wreck-actdp-diagnosis.md).

The unchanged expert-command replay succeeds 12/12 (four states each at raw 30 Hz, packed 30 Hz and resampled 20 Hz). The current source geometry is unchanged for CargoRelease. The wrapper uses scene-local absolute base targets and joint targets; residual mode adds the current measured anchor once to all future targets, before20→30 Hz interpolation. It does not integrate residuals repeatedly. ACT replans every 24 control steps and DP every 12; DP's prior camera/state sample is two raw frames earlier at its replan times.

| Validation seed | ACT first >1 cm TCP divergence | DP residual first >1 cm TCP divergence | ACT closest intended rope joint | DP closest intended rope joint |
|---|---:|---:|---:|---:|
|6028|0.60s|0.87s|18.4 mm|159.0 mm|
|6033|0.73s|2.30s|60.9 mm|27.9 mm|
|6040|0.50s|0.43s|18.4 mm|29.0 mm|
|6051|0.57s|0.47s|47.7 mm|16.9 mm|

Divergence requires three consecutive recorded 30 Hz frames. These are diagnostic thresholds, not success criteria. Distances are to the central intended rope joint; summed contact magnitudes are not substituted for the physical local cutting gate. ACT has zero measured blade contact in three episodes and only 1.68 N maximum summed blade load in the fourth. DP residual has no measured blade contact in all four. The model can command closure while missing the strand, so changing the severance threshold would not correct its approach.

ACT's first commanded base target has about2 cm error even at the matched initial state. Teacher-forced ACT base-target median is8.82 mm in the first second versus0.93 mm globally. DP residual is9.25 mm in the first second, and the absolute CLIP variant49.92 mm. Global averages therefore conceal the early errors. Later on-policy observations and proprioception depart from demonstrated trajectories; low teacher-forced error does not establish closed-loop recovery.

## Intervention: replace only the first 6.4 seconds with expert commands

The ACT192-step expert-prefix diagnostic removes initial learned commands while retaining the same initial states, unchanged physics and subsequent policy. The first sustained TCP divergence moves to steps199,201,195,200:0.10–0.30 seconds after handover. During the 60 second diagnostic window, seed 6040 reaches physical severance; the other three do not. No complete task success is observed within that deliberately shorter window. This is **not** a full-horizon success-rate measurement or an autonomous policy result.

The intervention shows that initial command errors matter, but replacing the start does not fix subsequent alignment. It does not prove one unique optimizer/data cause. Sparse transition coverage, partial observability and distribution shift remain possible learning explanations; they are not presented as established integration defects.

## Established repairs and frozen final comparison

The preceding stage fixed DP's missing CLIP normalization and random evaluation transforms, added explicit residual command reconstruction, and replaced truncated validation with full held-out validation. Those repairs and their trained checkpoints are retained. Deterministic crop alone did not improve the old model sufficiently. No physics/contact gates, lights, scene or success thresholds are changed here.

Final checkpoint/variant selection is frozen in cargo_final_selection.json before final evaluation. ACT uses its minimum full-validation inference-L1 checkpoint. DP uses the residual/CLIP variant: both DP variants have0/4 validation success, and residual has better held-out command precision. Its checkpoint minimizes full-validation diffusion loss. Both final policies run autonomously from reset; no expert prefix, object state or expert phase is supplied.

Thirty new states 8000–8029 are separate from training, checkpoint validation and historically inspected test states 7000–7029. This list was frozen before the first final evaluation launch. Low final success is retained as measured; no further tuning on those states is allowed.

## Final ACT measurement (new fixed states)

The frozen ACT residual checkpoint completes 3/30 tasks on states 8000–8029. Four episodes sever the rope. States8003,8008,8017 satisfy complete release/withdrawal/hold at steps1669,2209,2677; state 8026 cuts but does not complete the contract before the terminal horizon. The other26 never sever. These outcomes were not used for further checkpoint or controller selection. The completed DP measurement appears below.

Contact summaries sampled at 30 Hz can miss brief forces that trigger the 480 Hz cutter gate. For example, the control-frame peak in state 8008 is below8 N, while its recorded physics-step cut event contains opposing blade-force components of 8.78 N and−12.67 N. Use the preserved cut events for threshold verification, not the lower-rate contact plot.

## Final DP measurement (new fixed states)

The frozen DP residual/CLIP checkpoint completes 1/30 tasks, with one first-episode severance. State8014 completes at step 2089. Four states terminate early (8002,8004,8025,8028);25 other states reach the horizon without severance. No second episodes are scored. The model and its action/image pipelines were not changed after final testing began.
