# Wall Toss — expert and water-effect comparison

The capsule is thrown through a real opening in a single green wall.
The receiver chamber and its legs have been removed, including every collider.
After passage the capsule freely sinks to the sand. Completion requires 10
consecutive contact-free frames beyond the wall, with no container bounds.
The dry capsule mass (100 g), diameter (50 mm), gripper, actuator limits and robot
camera mounts are unchanged. The revised water model includes the sphere's
33.543 g potential-flow added mass. Historical basket results are kept separate.

| Measurement | Still water | +Y current 0.2 m/s |
| --- | --- | --- |
| Outcome | Success | Aperture-edge collision; no full passage |
| First success | 7.80 s | — |
| Whole sphere behind plate | 7.333 s | — |
| Release vx | 0.5313 m/s | 0.5649 m/s |
| Base gap at release | 0.7054 m | 0.7198 m |
| Base gap at delivery | 0.8274 m | — |
| Minimum base gap, entire motion | 0.6705 m | 0.6695 m |
| Minimum capsule-to-aperture gap | 7.378 mm | Contact |
| Maximum monitored penetration | <0.001 mm | <0.001 mm |

The two complete 324 × 8 command arrays match exactly. Both movies are 10.8 s,
30 fps. The same initial seed 42 and scene are used. The current acts on the ROV
and the capsule, while low-level station keeping is active in both runs. There
is no adjustment of high-level commands in the current replay. `phase` in its
trace is the reference expert's command phase, **not** an outcome flag; use the
measured `success`, `crossed` and `valid_crossing` fields for the actual outcome.

In current, the capsule first contacts the upper/lateral aperture edge at 7.0 s,
with y≈77 mm. It loses forward speed and sinks outside. Still water passes with
about 7 mm minimum clearance. This is a paired nominal example, not an estimated
success rate or an ACT/DP benchmark.

The 0.70 m stand-off applies at release and the first complete crossing, not
every instant of braking. Both full-trajectory minimum distances are disclosed.
Checks that require a completed crossing remain false when there is no crossing;
this does not mean the failed current run had finger recontact.

`comparison.json` includes the measured traces, exact-command verification,
observed flow field checks and separate contact-free calculations from the same
release state. The latter are counterfactual calculations, not simulated expert
outcomes. Independent integration matches measured motion before the wall within
0.511 mm in calm water and 0.902 mm in current. This checks implementation
consistency, not accuracy against a water-tank experiment.

See [mission, model, assumptions and reproduction](../../docs/tasks/wall-toss.md).
Each case includes resolved config, actual mass/inertia/current, source hashes,
measured states, commands and the complete 30 Hz trace. Sphere/plate/sand
penetration and aperture clearance are monitored at 480 Hz; no full robot
collision audit is claimed. The viewer presents all three camera recordings.

```bash
sha256sum -c benchmarks/wall-toss-v2/SHA256SUMS
.venv/bin/python scripts/audit_wall_toss_demo.py benchmarks/wall-toss-v2/calm
.venv/bin/python scripts/audit_wall_toss_demo.py benchmarks/wall-toss-v2/current
```

Development pilots remain local. A first current trial wrote to a computed
property and therefore applied no current; it was rejected before publication.
Published traces record the actual nonzero field on every step. Earlier pilots
also exposed premature slipping and rim strikes; they were not reported as
successful expert delivery.

Scene v1 with a receiver and its media remain historical at commit `59b0297`;
those videos are removed from the current website. The wall-only scene is v2.
