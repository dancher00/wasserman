"""Repeat the three complete demo trajectories in the separate clean install.

Wait for the official campaign to finish successfully; never compete for physics.
This is installation reproduction on the same machine, not a new test cohort.
"""
import argparse
import datetime
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import numpy as np
from scipy.spatial.transform import Rotation

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--campaign', type=Path, required=True)
p.add_argument('--campaign-pid', type=int, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
clean = Path.cwd()
assert (clean / '.git').is_file(), 'Run inside the clean reproduction worktree'
a.campaign = a.campaign.resolve()
a.output = a.output.resolve()
a.output.mkdir(parents=True, exist_ok=False)
(a.output / 'runner.py').write_bytes(Path(__file__).read_bytes())
state = {'status': 'waiting for official campaign', 'pid': os.getpid(),
         'wait_for_pid': a.campaign_pid, 'completed': [], 'independent_machine': False,
         'scope': 'Full 180 s reproduction of each of the three separate seed91003 demos; not the 30-reset benchmark',
         'clean_checkout': str(clean), 'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()}

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def save():
    state['updated_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    temp = a.output / 'status-next.json'
    temp.write_text(json.dumps(state, indent=2) + '\n')
    temp.replace(a.output / 'status.json')

def call(arguments, label):
    state.update(status='running', active=label)
    save()
    with (a.output / (label + '.log')).open('x') as log:
        subprocess.run([sys.executable, *map(str, arguments)], cwd=clean,
                       env={**os.environ, 'OMP_NUM_THREADS': '4'}, stdout=log, stderr=subprocess.STDOUT, check=True)
    state['completed'].append(label)
    save()

save()
try:
    while True:
        official = json.loads((a.campaign / 'status.json').read_text())
        if official['status'] == 'stopped':
            raise RuntimeError('Official campaign stopped: ' + official.get('error', ''))
        process = Path(f'/proc/{a.campaign_pid}/cmdline')
        if not process.exists():
            assert official['status'] == 'tests complete; inspect results and films before publication'
            break
        assert b'continue_campaign.py' in process.read_bytes()
        time.sleep(5)
    assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], text=True).strip()
    assert not subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', 'src', 'scripts'], text=True).strip()
    manifest_path = a.campaign / 'frozen-sources.json'
    manifest = json.loads(manifest_path.read_text())
    for name, expected in manifest['source_sha256'].items():
        assert sha(clean / name) == expected, name
    for name, expected in manifest['packages'].items():
        assert importlib.metadata.version(name) == expected, name
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=clean / '.deps/IsaacLab', text=True).strip() == manifest['isaaclab_git_head']
    git_diff = subprocess.run(['git', 'diff', 'HEAD'], cwd=clean / '.deps/IsaacLab', capture_output=True)
    (a.output / 'isaaclab-git-preflight.json').write_text(json.dumps({
        'command': ['git', 'diff', 'HEAD'], 'returncode': git_diff.returncode,
        'stdout_sha256': hashlib.sha256(git_diff.stdout).hexdigest(),
        'stderr': git_diff.stderr.decode(errors='replace'),
        'expected_sha256': manifest['isaaclab_diff_sha256'],
    }, indent=2) + '\n')
    git_diff.check_returncode()
    assert hashlib.sha256(git_diff.stdout).hexdigest() == manifest['isaaclab_diff_sha256']
    state['frozen_source_files_verified'] = len(manifest['source_sha256'])
    amendment_path = a.campaign / 'coordinate-audit-amendment.json'
    amendment = json.loads(amendment_path.read_text())
    assert sha(manifest_path) == amendment['original_frozen_manifest_sha256']
    for name, expected in amendment['source_sha256'].items():
        assert sha(clean / name) == expected, name
    state['coordinate_audit_amendment_sha256'] = sha(amendment_path)
    comparisons = []
    for mode in ['two-hands', 'support', 'free']:
        output = a.output / mode
        call(['scripts/run_bimanual_study.py', '--manifest', manifest_path,
              '--mode', mode, '--split', 'demo', '--physics-only', '--output-dir', output], mode)
        call(['scripts/analyze_bimanual_trace.py', output], mode + '-replay')
        call(['scripts/audit_bimanual_trace.py', output], mode + '-geometry')
        coordinate_output = a.output / 'coordinate-audits' / mode
        call(['scripts/audit_bimanual_coordinate_precision.py', output, '--output', coordinate_output], mode + '-coordinates')
        coordinate = json.loads((coordinate_output / 'report.json').read_text())
        assert coordinate['passed'] and coordinate['threshold_m'] == 1e-4
        assert coordinate['trace_sha256'] == sha(output / 'trace.npz')
        assert coordinate['geometry_audit_sha256'] == sha(output / 'geometry-audit.json')
        assert coordinate['source_sha256'] == amendment['source_sha256']['scripts/audit_bimanual_coordinate_precision.py']
        for row in coordinate['episodes']:
            assert row['passed'] and row['samples'] == 5400
            for field in ['recorded_vs_native_world', 'native_local_vs_cpu', 'coordinate_corrected_fk']:
                assert max(row[field + '_max_error_m'].values()) < 1e-4
        replay = json.loads((output / 'independent-replay.json').read_text())
        geometry = json.loads((output / 'geometry-audit.json').read_text())
        assert replay['complete'] and replay['finite'] and replay['recorded_success_agrees']
        assert replay['last_time_s'] >= 180 - 1 / 30 - 1e-6 and not replay['episodes'][-1]['success']
        for row in geometry['episodes']:
            assert not row['cad_collisions'] and row['max_joint_limit_excess_rad'] <= .002
            assert row['max_motor_force_N'] <= 1540.001
        original = a.campaign / f'demo-{mode}'
        with np.load(original / 'trace.npz') as source:
            reference = dict(source)
        with np.load(output / 'trace.npz') as source:
            reproduced = dict(source)
        np.testing.assert_allclose(reference['time'], reproduced['time'], atol=1e-6)
        rr = json.loads((original / 'report.json').read_text())
        cr = json.loads((output / 'report.json').read_text())
        assert rr['seeds'] == cr['seeds'] == [91003] and rr['dt'] == cr['dt'] == 1 / 240
        assert rr['source_files'] == cr['source_files'] and rr['successes'] == cr['successes']
        error = {
            'tcp_rms_m': max(float(np.sqrt(np.mean(np.sum((reference[k][:, 0] - reproduced[k][:, 0]) ** 2, axis=-1)))) for k in ['tool_position', 'left_tool_position']),
            'shaft_angle_max_deg': float(np.rad2deg(abs(reference['valve_angle'][:, 0] - reproduced['valve_angle'][:, 0]).max())),
            'base_orientation_max_deg': float(np.rad2deg((Rotation.from_quat(reference['quaternion'][:, 0]).inv() * Rotation.from_quat(reproduced['quaternion'][:, 0])).magnitude().max())),
            'joint_position_max_rad': float(abs(reference['joint_position'][:, 0] - reproduced['joint_position'][:, 0]).max()),
        }
        limits = {'tcp_rms_m': .01, 'shaft_angle_max_deg': 5, 'base_orientation_max_deg': .5, 'joint_position_max_rad': .02}
        comparison = {'mode': mode, 'seed': 91003, 'same_success': True,
                      'trace_bitwise_equal': all(np.array_equal(reference[k], reproduced[k]) for k in reference),
                      'reference_trace_sha256': sha(original / 'trace.npz'),
                      'reproduced_trace_sha256': sha(output / 'trace.npz'),
                      'errors': error, 'limits': limits, 'passed': all(error[k] <= limit for k, limit in limits.items())}
        comparisons.append(comparison)
        (a.output / 'comparisons.json').write_text(json.dumps(comparisons, indent=2) + '\n')
        assert comparison['passed'], comparison
    state.update(status='passed', active=None, comparisons=comparisons)
    save()
except BaseException as exc:
    state.update(status='stopped', error=repr(exc))
    save()
    raise
