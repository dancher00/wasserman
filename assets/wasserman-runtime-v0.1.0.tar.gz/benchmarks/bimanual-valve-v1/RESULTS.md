# Two-arm RotateValve: three physical control modes

All three scripted experts succeed on **30/30 paired test resets**. Cooperative
turning has lower mean base motion and peak motor utilization during the turning
phases in this calm-water setup. Grasping the rail provides no observed
improvement in these averages over parking the left arm.

| Mode | Success | Base orientation RMS (°) | Base displacement RMS (mm) | Peak motor utilization (%) |
|---|---:|---:|---:|---:|
| Left arm parked | 30/30 | 0.093 | 3.141 | 40.47 |
| Left arm on support | 30/30 | 0.095 | 3.409 | 40.73 |
| Both hands on wheel | 30/30 | 0.060 | 2.694 | 36.82 |

RMS is computed over all samples of both turning phases within each episode,
then averaged across the 30 episodes. The motor column averages each episode's
largest absolute motor force during those phases, divided by its native 1540 N
limit. These are descriptive reset averages, not training-seed estimates or
actuator-energy measurements. Full-episode curves retain settling, regrasp,
release and withdrawal; their plotted values are not the phase RMS in this table.

## Protocol and scope

The frozen states are 92000–92029, with identical sampled initial base offsets in
each condition. Every run records the complete 180-second horizon at 30 Hz, with
240 Hz physical integration. All powered episodes reach the final plan phase.
All three additional motors-disabled controls fail the unchanged signed
shaft-angle threshold of 170 degrees and are excluded from the denominator.
The three development states were checked at both 240 and 480 Hz before the
test cohort was opened.

This is a custom, free-floating twin-Oberon Rex with a separate 506 mm passive
wheel. Free/support conditions retain identical fixture geometry; the unused
rail is moved aside for the cooperative extension. Commands use measured state
and contact feedback. The comparison does not add learned-policy results, a
third native platform, or evidence of hardware transfer. Original single-arm
RotateValve ACT/DP scores and the articulated PressButton study remain unchanged.

In the cooperative mode, both hands have positive estimated signed interaction
work in both turns in **29/30** episodes. In seed 92025's second turn, left-hand
net work is −0.0072 J while right-hand net work is +1.2712 J. The episode still
succeeds. This 30 Hz contact estimate does not establish continuous bilateral
contact or positive contribution by every hand at every instant.

## Audits and reproducibility

All 90 powered trajectories pass the sampled native CAD self-collision, native
joint-position and motor-force checks. No claim is made about every physics
substep. The original absolute-world FK check exceeds 100 µm in two support
episodes and three free episodes because of float32 world-coordinate rounding.
A translation counterfactual isolates that effect. The disclosed supplemental
native-coordinate audit retains the 100 µm bound: maximum corrected errors are
61.162 µm (free), 61.182 µm (support) and 31.073 µm (cooperative). Original failed
diagnostics and all raw trajectories are retained; no physical episodes are
rerun or replaced to obtain these benchmark counts.

- [Complete summary and per-reset metrics](summary.json).
- [Frozen physical source manifest](frozen-sources.json).
- [Numerical-audit amendment](coordinate-audit-amendment.json) and
  [explanation](../../docs/studies/bimanual-coordinate-audit.md).
- [Reproduction commands](../../docs/studies/bimanual-valve-v1-reproduction.md).

The three final films use the separate, preselected reset 91003. Each is a full
180-second recording at 1280×720 and 30 fps, without audio or overlays. They replay
measured physical states in the existing tiled pool with a grounded textured
wall. Rotor animation follows recorded forces at a reduced display speed.
The films do not change dynamics or enter the benchmark denominator.

The clean-install execution check is reported separately from these 90 test
episodes: it repeats the three demo trajectories on the same machine. It does
not establish independent-machine replication or repeat the complete test cohort.
See the [machine-readable reproduction record](reproduction.json) for the
tested revision and full-trajectory comparisons.
